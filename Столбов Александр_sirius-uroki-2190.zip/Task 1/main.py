from functools import lru_cache

@lru_cache()
def tryer():
    with open('dict.txt', encoding="utf-8") as d:
        data = list(map(str.strip, d.readlines()))
    with open('queries_word.txt', encoding="utf-8") as queries, open('answer.txt', 'w', encoding="utf-8") as answer:
        for word1 in queries:
            word1 = word1.strip()
            answer.write(word1)
            flag = False
            b = ''
            if word1 in data:
                answer.write(' 0\n')
                continue
            for word_dict in data:
                word_log = [0]
                word = list(word1)
                word_dict = list(word_dict)
                if abs(len(word) - len(word_dict)) < 3 and abs(len(set(word) ^ set(word_dict))) < 5:
                    flag = True
                    #answer.write(' ' + ''.join(word_dict) + ';')

                    i = 0
                    while i < len(word):
                        # выходим из исправлений
                        if word_log[0] > 2 or word_log[-1] == ''.join(word_dict).strip():
                            break
                        # проверка на обмен местами соседних букв

                        if (i + 1 < len(word) and i + 1 < len(word_dict) and word[i] + word[i + 1] == word_dict[i + 1] + word_dict[i] and word[i] != word[i + 1]) and \
                                ((i + 2 < len(word) and i + 2 < len(word_dict) and
                                  ((word[i + 1] == word_dict[i + 2] and word_dict[i] == word[i + 2]) or
                                  (word[i] != word[i + 2] and word_dict[i] != word_dict[i + 2]))) or\
                                i + 2 >= len(word)):
                            word[i], word[i + 1] = word[i + 1], word[i]
                            word_log[0] += 1
                            word_log.append(''.join(word))
                        # проверка на обмен местами через одну с выкидом средней
                        if word_log[0] == 0:
                            ddd = ''
                            if i > 0 and i + 2 < len(word):
                                ddd += ''.join(word[:i - 1])
                            elif i + 3 < len(word):
                                ddd += word[i + 2] + word[i] + ''.join(word[i + 3:])
                            elif i + 2 < len(word):
                                ddd += word[i + 2] + word[i]
                            if list(ddd) == word_dict:
                                del word[i + 1]
                                word_log.append(''.join(word))
                                word[i], word[i + 1] = word[i + 1], word[i]
                                word_log[0] += 2
                                word_log.append(''.join(word))
                                b = f' {word_log[0]} {word_log[1]} {word_log[2]}'
                                break
                        # проверка на не совпадение букв
                        if i < len(word_dict) and word[i] != word_dict[i]:
                            # удаление лишний буквы не последней
                            if (i + 2 == len(word) and i < len(word_dict) and word[i + 1] == word_dict[i]) or \
                                (i + 2 < len(word) and i + 1 < len(word_dict) and (word[i + 1:i + 3] == word_dict[i: i + 2])) or \
                                    (i + 1 < len(word) and i + 1 >= len(word_dict) and word[i + 1] == word_dict[i]):
                                del word[i]
                                word_log[0] += 1
                                word_log.append(''.join(word))
                            # вставка пропущенной буквы
                            elif (i + 1 < len(word_dict) and word[i] == word_dict[i + 1] and i + 1 >= len(word)) or \
                                    ((i + 2 < len(word_dict) and word[i:i+2] == word_dict[i + 1:i + 3] and i + 2 >= len(word))) or\
                                        ((i + 2 < len(word_dict) and word[i] == word_dict[i + 1] and i + 2 < len(word)\
                                          and (word[i:i + 2] == word_dict[i + 1: i + 3] and
                                               word[i + 1:i + 3] != word_dict[i + 1: i + 3] or word[i] != word[i + 1]))):
                                word.insert(i, word_dict[i])
                                word_log[0] += 1
                                word_log.append(''.join(word))
                                i += 2
                            # исправление неверно введеной
                            elif (i + 1 < len(word_dict) and i + 1 < len(word) and word[i + 1] == word_dict[i + 1]) or \
                                    (i + 1 == len(word) and i + 1 == len(word_dict)):
                                del word[i]
                                word.insert(i, word_dict[i])
                                word_log[0] += 1
                                word_log.append(''.join(word))
                                i += 1

                            elif i + 1 < len(word_dict) and i + 1 < len(word) and word[i + 1] != word_dict[i + 1] and\
                                    len(word) <= len(word_dict):
                                del word[i]
                                word.insert(i, word_dict[i])
                                word_log[0] += 1
                                word_log.append(''.join(word))
                                i += 1
                            else:
                                del word[i]
                                word_log[0] += 1
                                word_log.append(''.join(word))

                        # отрезаем лишние буквы в конце
                        elif i >= len(word_dict) and i < len(word) and abs(len(word) - len(word_dict)) < 2:
                            word_log[0] += 1
                            word_log.append(''.join(word[:i]))
                            i += 1
                        # дописываем нехватающие буквы
                        elif i == len(word) - 1 and len(word) < len(word_dict):
                            word.extend(word_dict[len(word)])
                            word_log[0] += 1
                            word_log.append(''.join(word))
                        # буквы равны переходим к следующей
                        else:
                            i += 1

                    if word_log[-1] == ''.join(word_dict).strip():
                        if word_log[0] == 2 and b == '':
                            b = f' {word_log[0]} {word_log[1]} {word_log[2]}'
                        elif word_log[0] == 1:
                            b = f' {word_log[0]} {word_log[1]}'
                            break

            if b and flag:
                answer.write(b + '\n')
            else:
                answer.write(' 3+\n')


tryer()
