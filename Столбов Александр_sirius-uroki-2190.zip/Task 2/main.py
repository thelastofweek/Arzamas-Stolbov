from functools import lru_cache


@lru_cache()
def tryer():
    with open('universities.txt', encoding="utf-8") as d:
        data = list(map(str.strip, d.readlines()))
        dict = list(set(' '.join(data).lower().split()))

    with open('queries.txt', encoding="utf-8") as queries, open('answer.txt', 'w', encoding="utf-8") as answer,\
            open('repit.txt', 'w', encoding="utf-8") as repit:
        for line in queries:
            # исправление названия
            list_word = line.strip().lower().split()
            line_mod = ''
            #print(list_word)
            for i in list_word:
                ost = 10 ** 4
                copy_word = ''
                if i in dict:
                    line_mod += i + ' '
                    continue
                for j in dict:
                    a = list(i)  # список букв в анализируемом слове названии
                    b = list(j)  # список букв сопоставляемого слова названия универа
                    c = []  # список совпавших букв
                    for k in i:
                        if k in b:
                            b.remove(k)
                            a.remove(k)
                        else:
                            c.append(k)

                    x = len(c) + len(a) + len(b)
                    if x < ost:
                        ost = x
                        copy_word = j

                line_mod += copy_word + ' '
            print(line_mod)

            # фильтр названия
            copy_name = [] # список для хранения университетов прошедших фильтр
            ostatok = 10**6
            index = 0
            max_and = 0
            min_ost = 1000

            ''' Идея фильтра формируем 3 списка по буквам, из анализируемого названия,
            эталона слова и совпавших букв'''
            for j in data:
                '''для начала фильтр по пересечению и остаткам множеств слов из двух названий'''
                if set(line_mod.split()) == set(j.lower().split()):
                    index = data.index(j)
                    copy_name.clear()
                    copy_name.append(j)
                    break
                n = len(set(line_mod.split()) & set(j.lower().split()))
                m = min(len(set(line_mod.split()) ^ set(j.lower().split())), len(set(j.lower().split()) - set(line_mod.split())))
                if (n > max_and) or (n == max_and and m <= min_ost):
                    if n > max_and:
                        ostatok = 10**6
                        max_and = n

                    min_ost = m
                    a = list(line_mod.replace(' ', '')) # список букв в анализируемом названии
                    b = list(j.lower().replace(' ', '')) # список букв сопоставляемого универа
                    c = []              # список совпавших букв
                    for i in line_mod.replace(' ', ''):
                        if i in b:
                            b.remove(i)
                            a.remove(i)
                        else:
                            c.append(i)
                    '''Ищю минимум по сумме остатков, чисто по сумме фильтр проходило до 10 названий
                    пришлось накинуть весов. С таким вариантом весов результат успешного фильтра 96%'''
                    x = len(c) + len(a) * 8 + len(b) * 2
                    if x < ostatok:
                        ostatok = x
                        index = data.index(j)
                        copy_name.clear()
                        copy_name.append(j)
                    elif x == ostatok:
                        copy_name.append(j)
            #answer.write(line)
            '''тут  дополнительный фильтр если всетаки первый прошло более 1 института
            тут я писал глубокой ночью, теперь сам не понимаю почему он работает 
            но выбирает нужный вуз, если конечно он прошел первый фильтр
            '''
            if len(copy_name) == 1:
                answer.write(data[index] + '\n')
            else:
                elem = copy_name[0]
                for j in copy_name:
                    a = []
                    b = list(j.lower().replace(' ', ''))
                    min_a = 100
                    for i in line_mod:
                        if i in b:
                            b.remove(i)
                        else:
                            a.append(i)
                    if len(a) < len(b) and len(a) < min_a:
                        elem = j
                        min_a = len(a)
                answer.write(data[data.index(elem)] + '\n')
            #answer.write('\n')

            repit.write(line)
            for j in copy_name:
                repit.write(j + '\n')
            repit.write('\n')


tryer()
